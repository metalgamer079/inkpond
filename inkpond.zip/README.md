# Inkpond

A frame-by-frame animation studio for Android. Original app and original code (MIT), not affiliated with any other animation software.

## Get the APK (GitHub does the build)

1. Create a new GitHub repository and upload everything in this folder (keep the hidden `.github` folder).
2. Open the **Actions** tab. The **Build APK** workflow runs on every push (or press *Run workflow*). It takes about 5-8 minutes.
3. Open **Releases** (right side of the repo page), pick the latest build and download `Inkpond.apk`.
4. Open the file on your Android phone and allow "install unknown apps" for your browser when asked.

The APK is signed with the fixed key in `signing/`, so a newer build installs over an older one and your drawings are kept. That key is public (like the standard Android debug key): fine for personal use, not for the Play Store.

If the workflow turns red, open the failed run, copy the last lines of the failing step and ask for a fix.

## What it does

- Pen with stylus pressure, eraser, bucket fill (fills on the visible picture, paints on the active layer), colour picker, HSV colour wheel, brush size and opacity
- Frames with per-frame hold length, copy, delete, reorder
- Layers: add, delete, reorder, hide, lock, opacity, rename, clear
- Onion skin (red = before, green = after, 0 to 3 frames each way)
- Playback with FPS and loop
- Pinch to zoom, two fingers to pan, palm rejection while a stylus is in use
- Undo and redo
- Autosave on the device
- Export: GIF, PNG frames (ZIP, one image per frame at your FPS), video (MP4 or WebM depending on the phone), and an editable `.inkpond` project file you can reopen later

## Not included (yet)

Bones and IK, vector brushes, symbols, mesh deform, effects, audio tracks, and opening project files from other apps.

## Run it in a browser

```
python3 -m http.server -d www 8000
```

then open http://localhost:8000

## Layout

- `www/` the whole app (plain HTML, CSS and JavaScript, no build step)
- `.github/workflows/build-apk.yml` generates the Android project with Capacitor and builds the APK
- `signing/` the fixed debug signing key
- `resources/` launcher icon, splash colour (made by `tools/make-icons.py`)
