"""Draws the Inkpond pixel-art icon (an ink drop over a ripple) at every Android density.
Usage: python3 tools/make-icons.py <repo-root>
"""
import os, sys
from PIL import Image, ImageDraw

ROOT = sys.argv[1] if len(sys.argv) > 1 else "."
RES = os.path.join(ROOT, "resources", "android", "res")
BG = (20, 18, 43, 255)  # #14122B
COL = {"X": (244, 239, 230, 255), "h": (53, 214, 196, 255), "r": (53, 214, 196, 255)}
ART = [
    "................",
    ".......XX.......",
    ".......XX.......",
    "......XXXX......",
    "......XXXX......",
    ".....XXXXXX.....",
    ".....XXhXXX.....",
    "....XXXhXXXX....",
    "....XXXhXXXX....",
    "....XXXXXXXX....",
    ".....XXXXXX.....",
    "......XXXX......",
    "...rrrrrrrrrr...",
    ".rrr........rrr.",
    "...rrrrrrrrrr...",
    "................",
]


def art(size, fill, bg=None, shape="square"):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    if bg:
        if shape == "round":
            d.ellipse([0, 0, size - 1, size - 1], fill=bg)
        else:
            d.rounded_rectangle([0, 0, size - 1, size - 1], radius=size // 6, fill=bg)
    cell = max(1, int(size * fill) // 16)
    off = (size - cell * 16) // 2
    for y, row in enumerate(ART):
        for x, ch in enumerate(row):
            if ch in COL:
                d.rectangle([off + x * cell, off + y * cell, off + (x + 1) * cell - 1, off + (y + 1) * cell - 1], fill=COL[ch])
    return img


dens = {"mdpi": 1, "hdpi": 1.5, "xhdpi": 2, "xxhdpi": 3, "xxxhdpi": 4}
for name, k in dens.items():
    folder = os.path.join(RES, "mipmap-" + name)
    os.makedirs(folder, exist_ok=True)
    legacy, adaptive = int(48 * k), int(108 * k)
    art(legacy, 0.72, BG).save(os.path.join(folder, "ic_launcher.png"))
    art(legacy, 0.72, BG, "round").save(os.path.join(folder, "ic_launcher_round.png"))
    art(adaptive, 0.46).save(os.path.join(folder, "ic_launcher_foreground.png"))

vals = os.path.join(RES, "values")
os.makedirs(vals, exist_ok=True)
with open(os.path.join(vals, "ic_launcher_background.xml"), "w") as f:
    f.write('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#14122B</color>\n</resources>\n')

Image.new("RGBA", (32, 32), BG).save(os.path.join(ROOT, "resources", "splash.png"))
art(512, 0.7, BG).save(os.path.join(ROOT, "resources", "store-icon.png"))
print("icons written")
