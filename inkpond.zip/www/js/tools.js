'use strict';
/* Inkpond tools: pointer handling, pen / eraser / fill / pick / pan / pinch */
const ptrs = new Map();
let P = null, G = null, spaceDown = false, lastPen = 0;

const wid = (e, erase) => S.size * (erase ? 2 : 1) * (e.pointerType === 'pen' ? 0.2 + 0.8 * (e.pressure || 0.5) : 1);
function pt(e) {
  const r = $('#view').getBoundingClientRect(), v = S.view;
  return { x: (e.clientX - r.left - v.x) / v.z, y: (e.clientY - r.top - v.y) / v.z };
}
function editable() {
  const L = curLayer();
  if (L.lock) { toast('Layer is locked'); return false; }
  if (!L.vis) { toast('Layer is hidden'); return false; }
  return true;
}

function initPointer() {
  const v = $('#view');
  v.addEventListener('pointerdown', onDown);
  v.addEventListener('pointermove', onMove);
  v.addEventListener('pointerup', onUp);
  v.addEventListener('pointercancel', onUp);
  v.addEventListener('wheel', onWheel, { passive: false });
  v.addEventListener('contextmenu', e => e.preventDefault());
}

function onDown(e) {
  e.preventDefault();
  if (e.pointerType === 'pen') lastPen = performance.now();
  else if (e.pointerType === 'touch' && performance.now() - lastPen < 1200) return; // palm rejection
  $('#view').setPointerCapture(e.pointerId);
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY, t: e.pointerType });
  if (S.playing) { stopPlay(); return; }
  const touches = [...ptrs.values()].filter(p => p.t === 'touch').length;
  if (touches >= 2) { cancelOp(); G = gestureStart(); return; }
  if (ptrs.size > 1 || G) return;
  begin(e.button === 1 || spaceDown ? 'hand' : S.tool, e);
}
function onMove(e) {
  const p = ptrs.get(e.pointerId);
  if (!p) return;
  p.x = e.clientX; p.y = e.clientY;
  if (G) { gestureMove(); return; }
  if (!P || P.id !== e.pointerId) return;
  if (P.kind === 'stroke') strokeMove(e);
  else if (P.kind === 'pan') { S.view = { z: S.view.z, x: P.vx + e.clientX - P.sx, y: P.vy + e.clientY - P.sy, fit: false }; render(); }
  else if (P.kind === 'pick') pick(pt(e));
}
function onUp(e) {
  ptrs.delete(e.pointerId);
  if (G) { if ([...ptrs.values()].filter(p => p.t === 'touch').length < 2) G = null; return; }
  if (P && P.id === e.pointerId) { if (P.kind === 'stroke') strokeEnd(); else P = null; }
}
function onWheel(e) {
  e.preventDefault();
  const r = $('#view').getBoundingClientRect(), v = S.view, mx = e.clientX - r.left, my = e.clientY - r.top;
  const z = clamp(v.z * Math.exp(-e.deltaY * 0.0015), 0.05, 20);
  S.view = { z, x: mx - (mx - v.x) / v.z * z, y: my - (my - v.y) / v.z * z, fit: false };
  render();
}

/* ---------- pinch / two-finger pan ---------- */
function twoTouches() { return [...ptrs.values()].filter(p => p.t === 'touch').slice(0, 2); }
function gestureStart() {
  const [a, b] = twoTouches(), r = $('#view').getBoundingClientRect();
  return { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2 - r.left, my: (a.y + b.y) / 2 - r.top, v: { ...S.view } };
}
function gestureMove() {
  const [a, b] = twoTouches(); if (!b) return;
  const r = $('#view').getBoundingClientRect();
  const d = Math.hypot(a.x - b.x, a.y - b.y) || 1, mx = (a.x + b.x) / 2 - r.left, my = (a.y + b.y) / 2 - r.top;
  const z = clamp(G.v.z * d / G.d, 0.05, 20);
  const cx = (G.mx - G.v.x) / G.v.z, cy = (G.my - G.v.y) / G.v.z;
  S.view = { z, x: mx - cx * z, y: my - cy * z, fit: false };
  render();
}

/* ---------- tools ---------- */
function begin(tool, e) {
  if (tool === 'hand') { P = { kind: 'pan', id: e.pointerId, sx: e.clientX, sy: e.clientY, vx: S.view.x, vy: S.view.y }; return; }
  if (tool === 'pick') { P = { kind: 'pick', id: e.pointerId }; pick(pt(e)); return; }
  if (!editable()) return;
  if (tool === 'fill') { floodFill(pt(e)); return; }
  const erase = tool === 'eraser', f = curFrame(), lid = curLayer().id, c = cel(f, lid, true);
  const p = pt(e), w = wid(e, erase);
  let x, backup = null;
  if (erase) {
    backup = mk(S.w, S.h); backup.getContext('2d').drawImage(c, 0, 0);
    x = c.getContext('2d'); x.save(); x.globalCompositeOperation = 'destination-out';
  } else {
    S.stroke = { cv: mk(S.w, S.h), alpha: S.alpha };
    x = S.stroke.cv.getContext('2d');
  }
  x.fillStyle = x.strokeStyle = erase ? '#000' : S.color;
  P = { kind: 'stroke', erase, id: e.pointerId, f, lid, c, backup, x, pts: [p], ws: [w], box: [p.x, p.y, p.x, p.y], maxw: w };
  x.beginPath(); x.arc(p.x, p.y, w / 2, 0, 7); x.fill();
  render();
}

function strokeMove(e) {
  const list = e.getCoalescedEvents ? e.getCoalescedEvents() : [];
  for (const ev of list.length ? list : [e]) {
    const p = pt(ev), q = P.pts[P.pts.length - 1];
    if (Math.hypot(p.x - q.x, p.y - q.y) < 0.6) continue;
    const w = wid(ev, P.erase), b = P.box;
    P.pts.push(p); P.ws.push(w); P.maxw = Math.max(P.maxw, w);
    b[0] = Math.min(b[0], p.x); b[1] = Math.min(b[1], p.y); b[2] = Math.max(b[2], p.x); b[3] = Math.max(b[3], p.y);
    seg(P);
  }
  render();
}
function seg(s) {
  const { x, pts, ws } = s, n = pts.length;
  let a, c, b;
  if (n === 2) { a = pts[0]; c = pts[0]; b = mid(pts[0], pts[1]); }
  else { a = mid(pts[n - 3], pts[n - 2]); c = pts[n - 2]; b = mid(pts[n - 2], pts[n - 1]); }
  x.lineCap = x.lineJoin = 'round'; x.lineWidth = (ws[n - 2] + ws[n - 1]) / 2;
  x.beginPath(); x.moveTo(a.x, a.y); x.quadraticCurveTo(c.x, c.y, b.x, b.y); x.stroke();
}
function strokeEnd() {
  const { x, pts, ws, f, lid, c, erase } = P, n = pts.length;
  if (n > 1) {
    const a = mid(pts[n - 2], pts[n - 1]);
    x.lineWidth = ws[n - 1]; x.beginPath(); x.moveTo(a.x, a.y); x.lineTo(pts[n - 1].x, pts[n - 1].y); x.stroke();
  }
  const pad = P.maxw / 2 + 2, b = P.box, r = rect([b[0] - pad, b[1] - pad, b[2] + pad, b[3] + pad]);
  let before = null;
  if (erase) { x.restore(); before = r && crop(P.backup, r); }
  else {
    before = r && crop(c, r);
    const cx = c.getContext('2d'); cx.globalAlpha = S.stroke.alpha; cx.drawImage(S.stroke.cv, 0, 0); cx.globalAlpha = 1;
    S.stroke = null;
    addRecent(S.color);
  }
  if (r) pushPix(f, lid, c, r, before, crop(c, r));
  touch(f, lid);
  P = null; render();
}
function cancelOp() {
  if (P && P.kind === 'stroke') {
    if (P.erase) { P.x.restore(); const x = P.c.getContext('2d'); x.clearRect(0, 0, S.w, S.h); x.drawImage(P.backup, 0, 0); }
    else S.stroke = null;
  }
  P = null; render();
}

function pick(p) {
  const t = mk(1, 1), x = t.getContext('2d', { willReadFrequently: true });
  x.translate(-Math.floor(p.x), -Math.floor(p.y));
  compose(x, curFrame(), { bg: true, noStroke: true });
  const d = x.getImageData(0, 0, 1, 1).data;
  setColor('#' + [d[0], d[1], d[2]].map(v => v.toString(16).padStart(2, '0')).join(''));
}

function hexRgb(h) { const n = parseInt(h.slice(1), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; }

/* bucket fill: finds the region on the visible picture, paints it on the active layer */
function floodFill(p) {
  const f = curFrame(), w = S.w, h = S.h, sx = Math.floor(p.x), sy = Math.floor(p.y);
  if (sx < 0 || sy < 0 || sx >= w || sy >= h) return;
  const t = mk(w, h), tx = t.getContext('2d', { willReadFrequently: true });
  compose(tx, f, { bg: true, noStroke: true });
  const d = tx.getImageData(0, 0, w, h).data, i0 = (sy * w + sx) * 4, r = d[i0], g = d[i0 + 1], b = d[i0 + 2];
  const ok = i => Math.abs(d[i] - r) + Math.abs(d[i + 1] - g) + Math.abs(d[i + 2] - b) <= 60;
  const m = new Uint8Array(w * h), st = [sx, sy];
  let x0 = sx, x1 = sx, y0 = sy, y1 = sy;
  while (st.length) {
    const y = st.pop(), x = st.pop();
    let xl = x;
    while (xl >= 0 && !m[y * w + xl] && ok((y * w + xl) * 4)) xl--;
    xl++;
    let up = false, dn = false;
    for (let xi = xl; xi < w && !m[y * w + xi] && ok((y * w + xi) * 4); xi++) {
      m[y * w + xi] = 1;
      if (xi < x0) x0 = xi; if (xi > x1) x1 = xi; if (y < y0) y0 = y; if (y > y1) y1 = y;
      if (y > 0) { const o = !m[(y - 1) * w + xi] && ok(((y - 1) * w + xi) * 4); if (o && !up) st.push(xi, y - 1); up = o; }
      if (y < h - 1) { const o = !m[(y + 1) * w + xi] && ok(((y + 1) * w + xi) * 4); if (o && !dn) st.push(xi, y + 1); dn = o; }
    }
  }
  const box = rect([x0 - 1, y0 - 1, x1 + 2, y1 + 2]);
  if (!box) return;
  const c = cel(f, curLayer().id, true), before = crop(c, box);
  const img = new ImageData(box.w, box.h), [cr, cg, cb] = hexRgb(S.color), o = img.data;
  const on = (x, y) => x >= 0 && y >= 0 && x < w && y < h && m[y * w + x];
  for (let y = 0; y < box.h; y++) for (let x = 0; x < box.w; x++) {
    const X = box.x + x, Y = box.y + y;
    if (on(X, Y) || on(X - 1, Y) || on(X + 1, Y) || on(X, Y - 1) || on(X, Y + 1)) { const j = (y * box.w + x) * 4; o[j] = cr; o[j + 1] = cg; o[j + 2] = cb; o[j + 3] = 255; }
  }
  const layer = mk(box.w, box.h); layer.getContext('2d').putImageData(img, 0, 0);
  const cx = c.getContext('2d'); cx.globalAlpha = S.alpha; cx.drawImage(layer, box.x, box.y); cx.globalAlpha = 1;
  pushPix(curFrame(), curLayer().id, c, box, before, crop(c, box));
  touch(curFrame(), curLayer().id); addRecent(S.color); render();
}
