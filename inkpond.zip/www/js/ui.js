'use strict';
/* Inkpond ui: wiring, colour picker, layers, menu, boot */
const PRESETS = ['#1b1b2f', '#ffffff', '#e63946', '#ff9f1c', '#ffd60a', '#2ec4b6', '#3a86ff', '#8338ec', '#ff5d8f', '#8d5524', '#5c946e', '#a8dadc', '#6c757d', '#f4a261', '#b5179e', '#000000'];
let HSV = { h: 0, s: 0, v: 0 }, recent = [];

/* ---------- colour ---------- */
function hsv2hex(h, s, v) {
  const f = n => { const k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
  return '#' + [f(5), f(3), f(1)].map(x => Math.round(x * 255).toString(16).padStart(2, '0')).join('');
}
function hex2hsv(hex) {
  const [r, g, b] = hexRgb(hex).map(x => x / 255), mx = Math.max(r, g, b), d = mx - Math.min(r, g, b);
  let h = 0;
  if (d) { h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; if (h < 0) h += 360; }
  return { h, s: mx ? d / mx : 0, v: mx };
}
function setColor(hex) {
  S.color = hex;
  const o = hex2hsv(hex); if (o.s < 0.01) o.h = HSV.h;
  HSV = o; paintColorUI();
}
function applyHSV() { S.color = hsv2hex(HSV.h, HSV.s, HSV.v); paintColorUI(); }
function paintColorUI() {
  $('#swatch').style.background = S.color; $('#hex').value = S.color; $('#hue').value = Math.round(HSV.h);
  drawSV(); savePrefs();
}
function drawSV() {
  const c = $('#sv'), x = c.getContext('2d'), w = c.width, h = c.height;
  x.fillStyle = hsv2hex(HSV.h, 1, 1); x.fillRect(0, 0, w, h);
  let g = x.createLinearGradient(0, 0, w, 0); g.addColorStop(0, '#ffffff'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g; x.fillRect(0, 0, w, h);
  g = x.createLinearGradient(0, 0, 0, h); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, '#000000');
  x.fillStyle = g; x.fillRect(0, 0, w, h);
  const px = HSV.s * w, py = (1 - HSV.v) * h;
  x.lineWidth = 2; x.strokeStyle = '#fff'; x.beginPath(); x.arc(px, py, 7, 0, 7); x.stroke();
  x.strokeStyle = '#000'; x.beginPath(); x.arc(px, py, 9, 0, 7); x.stroke();
}
function addRecent(hex) { recent = [hex, ...recent.filter(c => c !== hex)].slice(0, 8); savePrefs(); }
function renderSwatches() {
  const el = $('#swatches'); el.textContent = '';
  [...recent, ...PRESETS].forEach(c => { const i = document.createElement('i'); i.style.background = c; i.onclick = () => setColor(c); el.appendChild(i); });
}

/* ---------- prefs ---------- */
function savePrefs() {
  try { localStorage.setItem('inkpond.prefs', JSON.stringify({ tool: S.tool, color: S.color, size: S.size, alpha: S.alpha, onion: S.onion, recent })); } catch (e) { /* storage unavailable */ }
}
function loadPrefs() {
  try {
    const p = JSON.parse(localStorage.getItem('inkpond.prefs') || '{}');
    if (p.tool) S.tool = p.tool; if (p.color) S.color = p.color; if (p.size) S.size = p.size; if (p.alpha) S.alpha = p.alpha;
    if (p.onion) Object.assign(S.onion, p.onion); if (p.recent) recent = p.recent;
  } catch (e) { /* ignore */ }
}

/* ---------- sync ---------- */
function syncUI() {
  $('#bPlay').textContent = S.playing ? 'STOP' : 'PLAY';
  $('#bOnion').classList.toggle('on', S.onion.on);
  $('#fpsV').textContent = S.fps;
  $('#bUndo').disabled = !hist.length; $('#bRedo').disabled = !redoS.length;
  document.querySelectorAll('.tool').forEach(b => b.classList.toggle('on', b.dataset.t === S.tool));
  $('#size').value = S.size; $('#sizeV').textContent = S.size; $('#alpha').value = Math.round(S.alpha * 100);
  $('#mLoop').textContent = 'LOOP: ' + (S.loop ? 'ON' : 'OFF');
  $('#oB').textContent = S.onion.before; $('#oA').textContent = S.onion.after;
  if (curFrame()) { $('#fHold').textContent = curFrame().hold; $('#fDel').textContent = S.frames.length === 1 ? 'CLEAR' : 'DEL'; }
  if (!$('#sheetLayers').hidden) renderLayers();
}

/* ---------- sheets and dialogs ---------- */
function openSheet(id) {
  closeSheets(); $(id).hidden = false;
  if (id === '#sheetLayers') renderLayers();
  if (id === '#sheetColor') { renderSwatches(); drawSV(); }
}
function closeSheets() { document.querySelectorAll('.sheet').forEach(s => { s.hidden = true; }); }
/* last label is the confirm button; with `input` it resolves to the text (or null if cancelled) */
function ask(msg, labels, input) {
  return new Promise(res => {
    const inp = $('#mInput'), box = $('#mBtns');
    $('#mMsg').textContent = msg; inp.hidden = input == null; if (input != null) inp.value = input;
    box.textContent = '';
    labels.forEach((l, i) => {
      const b = document.createElement('button'); b.textContent = l;
      b.onclick = () => { $('#modal').hidden = true; res(input != null ? (i === labels.length - 1 ? inp.value : null) : i); };
      box.appendChild(b);
    });
    $('#modal').hidden = false;
  });
}

/* ---------- layers ---------- */
function renderLayers() {
  const el = $('#layerList'); el.textContent = '';
  for (let i = S.layers.length - 1; i >= 0; i--) {
    const L = S.layers[i], row = document.createElement('div'), eye = document.createElement('button'), lock = document.createElement('button'), nm = document.createElement('span');
    row.className = 'lrow' + (i === S.li ? ' on' : '');
    eye.textContent = L.vis ? '\u{1F441}' : '–';
    eye.onclick = () => { L.vis = !L.vis; S.lv++; scheduleSave(); renderLayers(); renderStrip(); render(); };
    lock.textContent = L.lock ? '\u{1F512}' : '\u{1F513}';
    lock.onclick = () => { L.lock = !L.lock; scheduleSave(); renderLayers(); };
    nm.className = 'nm'; nm.textContent = L.name;
    nm.onclick = async () => {
      if (i !== S.li) { S.li = i; renderLayers(); return; }
      const v = await ask('Rename layer', ['Cancel', 'OK'], L.name);
      if (v && v.trim()) { L.name = v.trim().slice(0, 24); scheduleSave(); renderLayers(); }
    };
    row.append(eye, lock, nm);
    if (i === S.li) {
      const r = document.createElement('input'); r.type = 'range'; r.min = 5; r.max = 100; r.value = Math.round(L.op * 100);
      r.oninput = () => { L.op = r.value / 100; S.lv++; render(); };
      r.onchange = () => { scheduleSave(); renderStrip(); };
      row.appendChild(r);
    }
    el.appendChild(row);
  }
}
function swapLayer(d) {
  const j = S.li + d;
  if (j < 0 || j >= S.layers.length) return;
  cmdLayers(() => { [S.layers[S.li], S.layers[j]] = [S.layers[j], S.layers[S.li]]; S.li = j; });
}
function clearLayer() {
  const f = curFrame(), L = curLayer(), c = f.cels[L.id];
  if (!c) return toast('Nothing to clear');
  if (L.lock) return toast('Layer is locked');
  const r = { x: 0, y: 0, w: S.w, h: S.h }, before = crop(c, r);
  c.getContext('2d').clearRect(0, 0, S.w, S.h);
  pushPix(f, L.id, c, r, before, mk(S.w, S.h)); touch(f, L.id); render();
}

/* ---------- tools ---------- */
function setTool(t) { S.tool = t; savePrefs(); syncUI(); }
function setOnion(k, d) { S.onion[k] = clamp(S.onion[k] + d, 0, 3); savePrefs(); syncUI(); render(); }

/* ---------- wiring ---------- */
function wire() {
  const on = (id, fn) => { $(id).onclick = fn; };
  on('#bUndo', undo); on('#bRedo', redo); on('#bPlay', togglePlay);
  on('#bOnion', () => { S.onion.on = !S.onion.on; savePrefs(); syncUI(); render(); });
  on('#bFpsM', () => setFps(S.fps - 1)); on('#bFpsP', () => setFps(S.fps + 1));
  on('#bLayers', () => openSheet('#sheetLayers')); on('#bMenu', () => openSheet('#sheetMenu')); on('#bColor', () => openSheet('#sheetColor'));
  on('#bFit', () => { S.view.fit = true; fitView(); render(); });
  document.querySelectorAll('.tool').forEach(b => { b.onclick = () => setTool(b.dataset.t); });
  $('#size').oninput = e => { S.size = +e.target.value; $('#sizeV').textContent = S.size; savePrefs(); };
  $('#alpha').oninput = e => { S.alpha = e.target.value / 100; savePrefs(); };
  on('#fAdd', addFrame); on('#fDup', dupFrame); on('#fDel', delFrame);
  on('#fL', () => moveFrame(-1)); on('#fR', () => moveFrame(1)); on('#fHm', () => changeHold(-1)); on('#fHp', () => changeHold(1));
  document.querySelectorAll('.scrim,.close').forEach(e => { e.onclick = closeSheets; });
  on('#lAdd', () => cmdLayers(() => { S.layers.splice(S.li + 1, 0, newLayer('Layer ' + (S.layers.length + 1))); S.li++; }));
  on('#lDel', () => { if (S.layers.length < 2) return toast('Need at least one layer'); cmdLayers(() => { S.layers.splice(S.li, 1); S.li = Math.min(S.li, S.layers.length - 1); }); });
  on('#lUp', () => swapLayer(1)); on('#lDown', () => swapLayer(-1)); on('#lClear', clearLayer);
  on('#mLoop', () => { S.loop = !S.loop; syncUI(); scheduleSave(); });
  on('#oBm', () => setOnion('before', -1)); on('#oBp', () => setOnion('before', 1));
  on('#oAm', () => setOnion('after', -1)); on('#oAp', () => setOnion('after', 1));
  on('#xGif', exportGif); on('#xPng', exportPng); on('#xVid', exportVideo); on('#xProj', exportProject);
  on('#mNew', async () => {
    if (await ask('Start a new project? The current one will be erased.', ['Cancel', 'New project']) !== 1) return;
    const [w, h] = $('#preset').value.split('x').map(Number);
    closeSheets(); newProject(w, h, $('#bgSel').value); refreshAll();
  });
  on('#mOpen', () => $('#file').click());
  $('#file').onchange = e => {
    const f = e.target.files[0]; e.target.value = '';
    if (f) runExport('Opening project', async () => { await openProjectFile(f); refreshAll(); });
  };
  /* colour picker */
  const sv = $('#sv'), svSet = e => {
    const r = sv.getBoundingClientRect();
    HSV.s = clamp((e.clientX - r.left) / r.width, 0, 1); HSV.v = 1 - clamp((e.clientY - r.top) / r.height, 0, 1); applyHSV();
  };
  sv.onpointerdown = e => { sv.setPointerCapture(e.pointerId); svSet(e); sv.onpointermove = svSet; };
  sv.onpointerup = () => { sv.onpointermove = null; };
  $('#hue').oninput = e => { HSV.h = +e.target.value; applyHSV(); };
  $('#hex').onchange = e => { const v = e.target.value.trim().replace(/^#?/, '#'); if (/^#[0-9a-f]{6}$/i.test(v)) setColor(v.toLowerCase()); else e.target.value = S.color; };
  /* keyboard (desktop) */
  addEventListener('keydown', e => {
    if (e.target.matches('input,select')) return;
    const k = e.key.toLowerCase(), mod = e.ctrlKey || e.metaKey;
    if (mod && k === 'z') { e.shiftKey ? redo() : undo(); e.preventDefault(); }
    else if (mod && k === 'y') redo();
    else if (k === ' ') { spaceDown = true; e.preventDefault(); }
    else if (k === 'enter') togglePlay();
    else if (k === ',') selectFrame(S.cur - 1);
    else if (k === '.') selectFrame(S.cur + 1);
    else if (k === '[') { S.size = clamp(S.size - 1, 1, 60); syncUI(); }
    else if (k === ']') { S.size = clamp(S.size + 1, 1, 60); syncUI(); }
    else if ({ p: 'pen', e: 'eraser', g: 'fill', i: 'pick', h: 'hand' }[k]) setTool({ p: 'pen', e: 'eraser', g: 'fill', i: 'pick', h: 'hand' }[k]);
  });
  addEventListener('keyup', e => { if (e.key === ' ') spaceDown = false; });
  addEventListener('pagehide', save);
  document.addEventListener('visibilitychange', () => { if (document.hidden) save(); });
}

/* ---------- boot ---------- */
addEventListener('DOMContentLoaded', async () => {
  loadPrefs(); wire(); initPointer();
  try { if (!(await loadProject())) newProject(960, 540, '#ffffff'); }
  catch (e) { console.warn(e); newProject(960, 540, '#ffffff'); }
  setColor(S.color);
  new ResizeObserver(() => resizeView()).observe($('#stage'));
  resizeView(); refreshAll();
});
