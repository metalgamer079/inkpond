'use strict';
/* Inkpond timeline: frame strip, frame operations, playback */
const TW = 160;
const thumbQ = new Set();
let thumbT = 0;

function thumbOf(f) {
  const th = Math.max(1, Math.round(TW * S.h / S.w));
  if (!f._th || f._th.height !== th) f._th = mk(TW, th);
  const x = f._th.getContext('2d');
  x.imageSmoothingQuality = 'high';
  x.setTransform(1, 0, 0, 1, 0, 0);
  x.fillStyle = S.bg; x.fillRect(0, 0, TW, th);
  x.scale(TW / S.w, th / S.h);
  compose(x, f, { noStroke: true });
  return f._th;
}
function onChange(f) {
  thumbQ.add(f);
  clearTimeout(thumbT);
  thumbT = setTimeout(() => { thumbQ.forEach(thumbOf); thumbQ.clear(); }, 200);
  scheduleSave();
}

function renderStrip() {
  const el = $('#strip');
  el.textContent = '';
  S.frames.forEach((f, i) => {
    const b = document.createElement('div'), n = document.createElement('i'), h = document.createElement('u');
    b.className = 'fr' + (i === S.cur ? ' on' : '');
    n.textContent = i + 1; h.textContent = f.hold > 1 ? 'x' + f.hold : ''; h.hidden = f.hold <= 1;
    b.append(thumbOf(f), n, h);
    b.onclick = () => { if (S.playing) stopPlay(); selectFrame(i); };
    el.appendChild(b);
  });
  markCur();
}
function markCur() {
  [...$('#strip').children].forEach((c, i) => c.classList.toggle('on', i === S.cur));
  const c = $('#strip').children[S.cur];
  if (c) c.scrollIntoView({ block: 'nearest', inline: 'center' });
  $('#fHold').textContent = curFrame().hold;
}
function selectFrame(i) { S.cur = clamp(i, 0, S.frames.length - 1); markCur(); render(); }

function refreshAll() {
  S.cur = clamp(S.cur, 0, S.frames.length - 1);
  S.li = clamp(S.li, 0, S.layers.length - 1);
  renderStrip(); syncUI(); render(); scheduleSave();
}

/* ---------- frame operations ---------- */
function addFrame() { cmdFrames(() => { S.frames.splice(S.cur + 1, 0, newFrame()); S.cur++; }); }
function dupFrame() {
  cmdFrames(() => {
    const src = curFrame(), f = newFrame();
    f.hold = src.hold;
    for (const lid in src.cels) { const c = mk(S.w, S.h); c.getContext('2d').drawImage(src.cels[lid], 0, 0); f.cels[lid] = c; S.dirty.add(f.id + '|' + lid); }
    S.frames.splice(S.cur + 1, 0, f); S.cur++;
  });
}
function delFrame() {
  cmdFrames(() => {
    if (S.frames.length === 1) S.frames[0] = newFrame();
    else { S.frames.splice(S.cur, 1); S.cur = Math.min(S.cur, S.frames.length - 1); }
  });
}
function moveFrame(d) {
  const j = S.cur + d;
  if (j < 0 || j >= S.frames.length) return;
  cmdFrames(() => { const [f] = S.frames.splice(S.cur, 1); S.frames.splice(j, 0, f); S.cur = j; });
}
function changeHold(d) {
  const f = curFrame(), a = f.hold, b = clamp(a + d, 1, 48);
  if (a === b) return;
  f.hold = b;
  push({ undo: () => { f.hold = a; }, redo: () => { f.hold = b; } });
  renderStrip(); scheduleSave();
}

/* ---------- playback ---------- */
let raf = 0;
const frameMs = i => S.frames[i].hold * 1000 / S.fps;
function togglePlay() { S.playing ? stopPlay() : startPlay(); }
function startPlay() {
  if (S.playing) return;
  if (!S.loop && S.cur === S.frames.length - 1) S.cur = 0;
  S.playing = true; syncUI();
  let i = S.cur, next = performance.now() + frameMs(i);
  const tick = now => {
    if (!S.playing) return;
    if (now - next > 500) next = now;
    while (now >= next) {
      i++;
      if (i >= S.frames.length) {
        if (!S.loop) { i = S.frames.length - 1; S.cur = i; stopPlay(); return; }
        i = 0;
      }
      next += frameMs(i);
    }
    if (i !== S.cur) { S.cur = i; markCur(); render(); }
    raf = requestAnimationFrame(tick);
  };
  raf = requestAnimationFrame(tick);
}
function stopPlay() {
  S.playing = false; cancelAnimationFrame(raf);
  markCur(); syncUI(); render();
}
function setFps(v) { S.fps = clamp(v, 1, 60); syncUI(); scheduleSave(); }
