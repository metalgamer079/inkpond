'use strict';
/* Inkpond core: project model, history, compositing, view */
const $ = (s, r = document) => r.querySelector(s);
const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
let _n = 0;
const uid = () => Date.now().toString(36) + (_n++).toString(36);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const mid = (a, b) => ({ x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 });

const S = {
  w: 960, h: 540, fps: 12, loop: true, bg: '#ffffff',
  layers: [], frames: [], cur: 0, li: 1, lv: 0,
  tool: 'pen', color: '#1b1b2f', size: 6, alpha: 1,
  onion: { on: false, before: 2, after: 1 },
  playing: false, view: { x: 0, y: 0, z: 1, fit: true },
  stroke: null, dirty: new Set(),
};
const hist = [], redoS = [];
const newFrame = () => ({ id: uid(), hold: 1, cels: {}, v: 0 });
const newLayer = name => ({ id: uid(), name, vis: true, lock: false, op: 1 });
const curFrame = () => S.frames[S.cur];
const curLayer = () => S.layers[S.li];

function newProject(w, h, bg) {
  S.w = w; S.h = h; S.bg = bg;
  S.layers = [newLayer('Color'), newLayer('Lines')]; S.li = 1; S.lv++;
  S.frames = [newFrame()]; S.cur = 0; S.dirty.clear();
  hist.length = 0; redoS.length = 0; S.view.fit = true;
}

function cel(f, lid, create) {
  let c = f.cels[lid];
  if (!c && create) c = f.cels[lid] = mk(S.w, S.h);
  return c || null;
}

/* mark a cel as changed: bumps the frame version, queues save + thumbnail */
function touch(f, lid) { f.v++; if (lid) S.dirty.add(f.id + '|' + lid); onChange(f); }

/* paint one frame (all visible layers) onto ctx at project scale */
function compose(ctx, f, o = {}) {
  if (o.bg) { ctx.fillStyle = S.bg; ctx.fillRect(0, 0, S.w, S.h); }
  const live = !o.noStroke && S.stroke && f === curFrame() ? curLayer().id : null;
  for (const L of S.layers) {
    if (!L.vis) continue;
    const c = f.cels[L.id];
    if (c) { ctx.globalAlpha = L.op; ctx.drawImage(c, 0, 0); }
    if (live === L.id) { ctx.globalAlpha = L.op * S.stroke.alpha; ctx.drawImage(S.stroke.cv, 0, 0); }
  }
  ctx.globalAlpha = 1;
}

/* ---------- history ---------- */
function push(cmd) { hist.push(cmd); if (hist.length > 80) hist.shift(); redoS.length = 0; syncUI(); }
function undo() { const c = hist.pop(); if (!c) return; c.undo(); redoS.push(c); refreshAll(); }
function redo() { const c = redoS.pop(); if (!c) return; c.redo(); hist.push(c); refreshAll(); }
function cmdFrames(fn) {
  const b = { fr: S.frames.slice(), cur: S.cur };
  fn();
  const a = { fr: S.frames.slice(), cur: S.cur };
  const set = s => { S.frames = s.fr.slice(); S.cur = s.cur; };
  push({ undo: () => set(b), redo: () => set(a) });
  refreshAll();
}
function cmdLayers(fn) {
  const b = { ly: S.layers.slice(), li: S.li };
  fn();
  const a = { ly: S.layers.slice(), li: S.li };
  const set = s => { S.layers = s.ly.slice(); S.li = s.li; S.lv++; };
  S.lv++;
  push({ undo: () => set(b), redo: () => set(a) });
  refreshAll();
}
function crop(src, r) { const c = mk(r.w, r.h); c.getContext('2d').drawImage(src, r.x, r.y, r.w, r.h, 0, 0, r.w, r.h); return c; }
function rect(b) {
  const x0 = Math.max(0, Math.floor(b[0])), y0 = Math.max(0, Math.floor(b[1]));
  const x1 = Math.min(S.w, Math.ceil(b[2])), y1 = Math.min(S.h, Math.ceil(b[3]));
  return x1 > x0 && y1 > y0 ? { x: x0, y: y0, w: x1 - x0, h: y1 - y0 } : null;
}
function pushPix(f, lid, c, r, before, after) {
  const put = img => {
    const x = c.getContext('2d');
    x.globalCompositeOperation = 'source-over'; x.globalAlpha = 1;
    x.clearRect(r.x, r.y, r.w, r.h); x.drawImage(img, r.x, r.y);
    touch(f, lid);
  };
  push({ undo: () => put(before), redo: () => put(after) });
}

/* ---------- view ---------- */
let pending = false;
function render() { if (!pending) { pending = true; requestAnimationFrame(draw); } }

function draw() {
  pending = false;
  const cv = $('#view'), ctx = cv.getContext('2d'), d = devicePixelRatio || 1, v = S.view;
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, cv.width, cv.height);
  ctx.setTransform(d * v.z, 0, 0, d * v.z, d * v.x, d * v.y);
  ctx.imageSmoothingEnabled = v.z < 2;
  ctx.globalAlpha = 0.4; ctx.fillStyle = '#000'; ctx.fillRect(4 / v.z, 4 / v.z, S.w, S.h); ctx.globalAlpha = 1;
  ctx.fillStyle = S.bg; ctx.fillRect(0, 0, S.w, S.h);
  if (S.onion.on && !S.playing) {
    for (let k = 1; k <= S.onion.before; k++) onionDraw(ctx, S.cur - k, '#ff4d6d', 0.5 / k);
    for (let k = 1; k <= S.onion.after; k++) onionDraw(ctx, S.cur + k, '#17c98f', 0.5 / k);
  }
  compose(ctx, curFrame());
}
function onionDraw(ctx, i, tint, a) {
  const f = S.frames[i]; if (!f) return;
  const o = f._on;
  let c = o && o.v === f.v && o.t === tint && o.lv === S.lv ? o.cv : null;
  if (!c) {
    c = mk(S.w, S.h);
    const x = c.getContext('2d');
    compose(x, f, { noStroke: true });
    x.globalCompositeOperation = 'source-in'; x.fillStyle = tint; x.fillRect(0, 0, S.w, S.h);
    f._on = { v: f.v, t: tint, lv: S.lv, cv: c };
  }
  ctx.globalAlpha = a; ctx.drawImage(c, 0, 0); ctx.globalAlpha = 1;
}
function resizeView() {
  const cv = $('#view'), r = $('#stage').getBoundingClientRect(), d = devicePixelRatio || 1;
  cv.width = Math.max(1, Math.round(r.width * d)); cv.height = Math.max(1, Math.round(r.height * d));
  if (S.view.fit) fitView();
  render();
}
function fitView() {
  const r = $('#stage').getBoundingClientRect(), z = Math.min(r.width / S.w, r.height / S.h) * 0.96;
  S.view = { z, x: (r.width - S.w * z) / 2, y: (r.height - S.h * z) / 2, fit: true };
}
let toastT = 0;
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 1600);
}
