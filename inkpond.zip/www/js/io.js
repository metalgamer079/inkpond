'use strict';
/* Inkpond io: autosave, project files, ZIP, GIF, video, sharing */

/* ---------- autosave (IndexedDB) ---------- */
let dbP = null;
function getDB() {
  return dbP || (dbP = new Promise((res, rej) => {
    const r = indexedDB.open('inkpond', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('kv');
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  }));
}
const reqP = r => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
const blobOf = (c, type = 'image/png') => new Promise(r => c.toBlob(r, type));
const tick = () => new Promise(r => setTimeout(r, 0));

function metaOf() {
  const ids = new Set(S.layers.map(l => l.id));
  return {
    v: 1, w: S.w, h: S.h, fps: S.fps, loop: S.loop, bg: S.bg, cur: S.cur, li: S.li, layers: S.layers,
    frames: S.frames.map(f => ({ id: f.id, hold: f.hold, cels: Object.keys(f.cels).filter(l => ids.has(l)) })),
  };
}
let saveT = 0;
function scheduleSave() { clearTimeout(saveT); saveT = setTimeout(save, 1200); }
async function save() {
  try {
    const db = await getDB(), meta = metaOf(), ids = new Set(S.layers.map(l => l.id));
    const keys = [...S.dirty]; S.dirty.clear();
    const jobs = await Promise.all(keys.map(async k => {
      const [fid, lid] = k.split('|'), f = S.frames.find(x => x.id === fid), c = f && f.cels[lid];
      return [k, c && ids.has(lid) ? await blobOf(c) : null];
    }));
    const keep = new Set();
    meta.frames.forEach(f => f.cels.forEach(l => keep.add('cel:' + f.id + '|' + l)));
    const tx = db.transaction('kv', 'readwrite'), st = tx.objectStore('kv');
    st.put(meta, 'meta');
    for (const [k, b] of jobs) b ? st.put(b, 'cel:' + k) : st.delete('cel:' + k);
    st.getAllKeys().onsuccess = e => e.target.result.forEach(k => { if (typeof k === 'string' && k.startsWith('cel:') && !keep.has(k)) st.delete(k); });
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = tx.onabort = () => rej(tx.error); });
  } catch (e) { console.warn('save failed', e); }
}
async function loadProject() {
  const db = await getDB();
  const get = k => reqP(db.transaction('kv').objectStore('kv').get(k));
  const meta = await get('meta');
  if (!meta) return false;
  await buildProject(meta, (fid, lid) => get('cel:' + fid + '|' + lid));
  return true;
}
async function buildProject(meta, getBlob) {
  Object.assign(S, { w: meta.w, h: meta.h, fps: meta.fps || 12, loop: meta.loop !== false, bg: meta.bg || '#ffffff' });
  S.layers = meta.layers; S.lv++; S.frames = [];
  for (const fm of meta.frames) {
    const f = { id: fm.id, hold: fm.hold || 1, cels: {}, v: 0 };
    for (const lid of fm.cels) {
      const b = await getBlob(fm.id, lid);
      if (b) { const bm = await createImageBitmap(b), c = mk(S.w, S.h); c.getContext('2d').drawImage(bm, 0, 0); f.cels[lid] = c; }
    }
    S.frames.push(f);
  }
  if (!S.frames.length) S.frames = [newFrame()];
  S.cur = clamp(meta.cur || 0, 0, S.frames.length - 1);
  S.li = clamp(meta.li == null ? 1 : meta.li, 0, S.layers.length - 1);
  S.dirty.clear(); hist.length = 0; redoS.length = 0; S.view.fit = true;
}

/* ---------- ZIP (store only) ---------- */
const crcT = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
function crc32(u) { let c = -1; for (let i = 0; i < u.length; i++) c = crcT[(c ^ u[i]) & 255] ^ (c >>> 8); return (c ^ -1) >>> 0; }
function makeZip(files) {
  const enc = new TextEncoder(), parts = [], central = [];
  let off = 0, cd = 0;
  for (const f of files) {
    const name = enc.encode(f.name), crc = crc32(f.data), n = f.data.length;
    const lh = new DataView(new ArrayBuffer(30));
    lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(12, 0x21, true);
    lh.setUint32(14, crc, true); lh.setUint32(18, n, true); lh.setUint32(22, n, true); lh.setUint16(26, name.length, true);
    parts.push(lh.buffer, name, f.data);
    const ch = new DataView(new ArrayBuffer(46));
    ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(14, 0x21, true);
    ch.setUint32(16, crc, true); ch.setUint32(20, n, true); ch.setUint32(24, n, true); ch.setUint16(28, name.length, true); ch.setUint32(42, off, true);
    central.push(ch.buffer, name);
    off += 30 + name.length + n; cd += 46 + name.length;
  }
  const end = new DataView(new ArrayBuffer(22));
  end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
  end.setUint32(12, cd, true); end.setUint32(16, off, true);
  return new Blob([...parts, ...central, end.buffer], { type: 'application/zip' });
}
function readZip(buf) { // reads archives written by makeZip
  const dv = new DataView(buf), u8 = new Uint8Array(buf), out = {};
  let o = 0;
  while (o + 30 <= buf.byteLength && dv.getUint32(o, true) === 0x04034b50) {
    const size = dv.getUint32(o + 18, true), nl = dv.getUint16(o + 26, true), xl = dv.getUint16(o + 28, true);
    if (dv.getUint16(o + 8, true) !== 0) throw new Error('Unsupported project file');
    const name = new TextDecoder().decode(u8.subarray(o + 30, o + 30 + nl)), s = o + 30 + nl + xl;
    out[name] = u8.subarray(s, s + size); o = s + size;
  }
  return out;
}

/* ---------- frames to pixels ---------- */
function frameCanvas(f) { const c = mk(S.w, S.h); compose(c.getContext('2d', { willReadFrequently: true }), f, { bg: true, noStroke: true }); return c; }

/* ---------- GIF ---------- */
function lzw(px) {
  let size = 9, next = 258, cur = 0, bits = 0;
  const dict = new Map(), bytes = [];
  const emit = c => { cur |= c << bits; bits += size; while (bits >= 8) { bytes.push(cur & 255); cur >>>= 8; bits -= 8; } };
  emit(256);
  let code = px[0];
  for (let i = 1; i < px.length; i++) {
    const k = px[i], key = code << 8 | k, hit = dict.get(key);
    if (hit !== undefined) { code = hit; continue; }
    emit(code);
    if (next === 4096) { emit(256); dict.clear(); next = 258; size = 9; }
    else { if (next >= 1 << size) size++; dict.set(key, next++); }
    code = k;
  }
  emit(code); emit(257);
  if (bits > 0) bytes.push(cur & 255);
  const out = [];
  for (let i = 0; i < bytes.length; i += 255) { const n = Math.min(255, bytes.length - i); out.push(n); for (let j = 0; j < n; j++) out.push(bytes[i + j]); }
  out.push(0);
  return Uint8Array.from(out);
}
async function buildGIF(prog = () => {}) {
  const w = S.w, h = S.h, imgs = [];
  const cnt = new Uint32Array(32768), sr = new Float64Array(32768), sg = new Float64Array(32768), sb = new Float64Array(32768);
  for (let i = 0; i < S.frames.length; i++) {
    const d = frameCanvas(S.frames[i]).getContext('2d').getImageData(0, 0, w, h).data;
    for (let j = 0; j < d.length; j += 4) { const k = (d[j] >> 3) << 10 | (d[j + 1] >> 3) << 5 | d[j + 2] >> 3; cnt[k]++; sr[k] += d[j]; sg[k] += d[j + 1]; sb[k] += d[j + 2]; }
    imgs.push(d); prog('Reading frame ' + (i + 1) + '/' + S.frames.length); await tick();
  }
  const order = [...cnt.keys()].filter(k => cnt[k]).sort((a, b) => cnt[b] - cnt[a]).slice(0, 256);
  const pal = new Uint8Array(768), map = new Int16Array(32768).fill(-1);
  order.forEach((k, i) => { pal[i * 3] = sr[k] / cnt[k]; pal[i * 3 + 1] = sg[k] / cnt[k]; pal[i * 3 + 2] = sb[k] / cnt[k]; map[k] = i; });
  const idxOf = k => {
    let m = map[k]; if (m >= 0) return m;
    const r = sr[k] / cnt[k], g = sg[k] / cnt[k], b = sb[k] / cnt[k]; let best = 1e12;
    for (let i = 0; i < order.length; i++) { const e = (pal[i * 3] - r) ** 2 + (pal[i * 3 + 1] - g) ** 2 + (pal[i * 3 + 2] - b) ** 2; if (e < best) { best = e; m = i; } }
    return map[k] = m;
  };
  const u16 = n => [n & 255, n >> 8 & 255], asc = s => [...s].map(c => c.charCodeAt(0));
  const out = [Uint8Array.from([...asc('GIF89a'), ...u16(w), ...u16(h), 0xF7, 0, 0]), pal,
    Uint8Array.from([0x21, 0xFF, 0x0B, ...asc('NETSCAPE2.0'), 3, 1, 0, 0, 0])];
  for (let i = 0; i < imgs.length; i++) {
    const d = imgs[i], px = new Uint8Array(w * h);
    for (let j = 0, p = 0; p < px.length; j += 4, p++) px[p] = idxOf((d[j] >> 3) << 10 | (d[j + 1] >> 3) << 5 | d[j + 2] >> 3);
    const delay = Math.max(2, Math.round(S.frames[i].hold * 100 / S.fps));
    out.push(Uint8Array.from([0x21, 0xF9, 4, 0, ...u16(delay), 0, 0, 0x2C, 0, 0, 0, 0, ...u16(w), ...u16(h), 0, 8]), lzw(px));
    prog('Encoding frame ' + (i + 1) + '/' + imgs.length); await tick();
  }
  out.push(Uint8Array.from([0x3B]));
  return new Blob(out, { type: 'image/gif' });
}

/* ---------- PNG sequence, video, project ---------- */
async function buildPngZip(prog = () => {}) {
  const files = [];
  for (let i = 0; i < S.frames.length; i++) {
    const f = S.frames[i], u = new Uint8Array(await (await blobOf(frameCanvas(f))).arrayBuffer());
    for (let k = 0; k < f.hold; k++) files.push({ name: 'frame_' + String(files.length + 1).padStart(4, '0') + '.png', data: u });
    prog('PNG ' + (i + 1) + '/' + S.frames.length); await tick();
  }
  return makeZip(files);
}
async function buildVideo(prog = () => {}) {
  if (!window.MediaRecorder || !HTMLCanvasElement.prototype.captureStream) throw new Error('Video export is not supported on this device');
  const type = ['video/mp4;codecs=avc1', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm'].find(t => MediaRecorder.isTypeSupported(t));
  if (!type) throw new Error('No video format available');
  const cv = mk(S.w & ~1, S.h & ~1), x = cv.getContext('2d'), stream = cv.captureStream(0), track = stream.getVideoTracks()[0];
  const rec = new MediaRecorder(stream, { mimeType: type, videoBitsPerSecond: 8e6 }), chunks = [];
  rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
  const stopped = new Promise(r => { rec.onstop = r; });
  const show = f => { x.drawImage(frameCanvas(f), 0, 0); if (track.requestFrame) track.requestFrame(); };
  rec.start();
  for (let i = 0; i < S.frames.length; i++) {
    show(S.frames[i]); prog('Recording ' + (i + 1) + '/' + S.frames.length);
    await new Promise(r => setTimeout(r, S.frames[i].hold * 1000 / S.fps));
  }
  show(S.frames[S.frames.length - 1]);
  await new Promise(r => setTimeout(r, 150));
  rec.stop(); await stopped;
  return { blob: new Blob(chunks, { type }), ext: type.startsWith('video/mp4') ? 'mp4' : 'webm' };
}
async function buildProjectFile() {
  const files = [{ name: 'project.json', data: new TextEncoder().encode(JSON.stringify(metaOf())) }];
  for (const f of S.frames) for (const lid in f.cels) {
    if (!S.layers.some(l => l.id === lid)) continue;
    files.push({ name: 'cels/' + f.id + '_' + lid + '.png', data: new Uint8Array(await (await blobOf(f.cels[lid])).arrayBuffer()) });
  }
  return makeZip(files);
}
async function openProjectFile(file) {
  const files = readZip(await file.arrayBuffer());
  if (!files['project.json']) throw new Error('Not an Inkpond project');
  const meta = JSON.parse(new TextDecoder().decode(files['project.json']));
  await buildProject(meta, (fid, lid) => { const u = files['cels/' + fid + '_' + lid + '.png']; return u ? new Blob([u], { type: 'image/png' }) : null; });
  S.frames.forEach(f => { for (const lid in f.cels) S.dirty.add(f.id + '|' + lid); });
}

/* ---------- hand a file to the user ---------- */
async function saveFile(blob, name) {
  const C = window.Capacitor, P = C && C.Plugins;
  if (C && C.isNativePlatform && C.isNativePlatform() && P && P.Filesystem && P.Share) {
    try {
      const b64 = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });
      await P.Filesystem.writeFile({ path: name, data: b64, directory: 'CACHE' });
      const { uri } = await P.Filesystem.getUri({ path: name, directory: 'CACHE' });
      await P.Share.share({ title: name, url: uri, dialogTitle: 'Save or share ' + name });
    } catch (e) { if (!/cancel/i.test(String((e && e.message) || e))) toast('Could not share: ' + ((e && e.message) || e)); }
    return;
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 4000);
}
const stamp = () => 'inkpond-' + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '');
const busy = m => { $('#busy').hidden = !m; if (m) $('#busyMsg').textContent = m; };
async function runExport(label, fn) {
  closeSheets(); busy(label + '...');
  try { await fn(); } catch (e) { console.warn(e); toast(String((e && e.message) || e)); }
  busy(null);
}
const exportGif = () => runExport('Making GIF', async () => saveFile(await buildGIF(busy), stamp() + '.gif'));
const exportPng = () => runExport('Making PNG frames', async () => saveFile(await buildPngZip(busy), stamp() + '-frames.zip'));
const exportVideo = () => runExport('Recording video', async () => { const v = await buildVideo(busy); await saveFile(v.blob, stamp() + '.' + v.ext); });
const exportProject = () => runExport('Saving project', async () => saveFile(await buildProjectFile(), stamp() + '.inkpond'));
